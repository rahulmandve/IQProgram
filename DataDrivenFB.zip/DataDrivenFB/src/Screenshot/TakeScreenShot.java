package Screenshot;

import java.io.File;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;


import Driver.LounchBrowser;

public class TakeScreenShot extends LounchBrowser
{	
	public static String screenshot(String name) throws Exception
	{
			
		SimpleDateFormat s=new SimpleDateFormat("dd_MM_YYYY hh_mm_ss");
		Date date=new Date();
		String str=s.format(date);
		
		TakesScreenshot t=(TakesScreenshot)d;	
		File src=t.getScreenshotAs(OutputType.FILE);
		String path=System.getProperty("user.dir")+"/ScreenShot/"+name+str+".png";
		File des=new File(path);
		FileUtils.copyFile(src,des);
		System.out.println("screenshot taken");
		
		return path;
		
		/*TakesScreenshot t=(TakesScreenshot)d;
			File src=t.getScreenshotAs(OutputType.FILE);
			
			String path=System.getProperty("user.dir")+"/ScreenShot/"+s+".png";
			//String path=System.getProperty("C:\\Users\\hp\\Desktop\\VideoRec"+s+".png");
			File desti=new File(path);
			FileUtils.copyFile(src,desti);
			System.out.println("screenshot taken");
			
			return path;
		 */
	}
}
