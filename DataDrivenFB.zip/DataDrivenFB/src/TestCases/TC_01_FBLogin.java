package TestCases;
import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Driver.LounchBrowser;
import ExcelSheetReader.ReadExcelData;
import Utility.ReadConfigFile;


public class TC_01_FBLogin extends LounchBrowser{
	
	ReadConfigFile rd=new ReadConfigFile();
	@Test(dataProvider="Excel")
	public void Login(String un,String pwd) throws Exception
	{
		d.findElement(By.id(rd.getUname())).sendKeys(un);
		d.findElement(By.id(rd.getpass())).sendKeys(pwd);
		d.findElement(By.id(rd.getClickButton())).click();
		Assert.assertEquals(d.getCurrentUrl(), "https://www.facebook.com/");
			
	}
	@DataProvider(name="Excel")
	public Object[][] testdata() throws Exception
	{

		ReadExcelData d=new ReadExcelData("C:\\Users\\hp\\Desktop\\TestData.xlsx");
		int rows=d.getRowCount(0);
		Object [][]data=new Object[rows][2];
		
		for(int i=0;i<rows;i++)
		{
			data[i][0]=d.getData(0, i, 0);
			data[i][1]=d.getData(0, i, 1);
		}
		
		
		return data;
	}

}
