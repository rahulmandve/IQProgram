package ChromeDriver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import Utility.ConfigReader;

public class LaunchBrowser {
	ConfigReader conf=new ConfigReader();
	public static WebDriver d;
	
	@BeforeMethod
	public void OpenBrowser()
	{
		System.setProperty("webdriver.chrome.driver",conf.getChromePath());
		d=new ChromeDriver();
		d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		d.manage().window().maximize();
		d.get(conf.getWebSiteUrl());
	}
	/*@AfterMethod
	public void CloseBrowser()
	{
		d.quit();
	}*/

}
