package Screenshot;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import ChromeDriver.LaunchBrowser;

public class TakescrShot extends LaunchBrowser{
	
	public static String CaptureScreenShot(String s) throws Exception
	{
		TakesScreenshot t=(TakesScreenshot)d;
		File src=t.getScreenshotAs(OutputType.FILE);
		String path=System.getProperty("user.dir")+"/ScreenShot/"+s+".png";
		File des=new File(path);
		FileUtils.copyFile(src, des);
		System.out.println("Screen Shot taken");
		
		return path;
		
	}
	

}
