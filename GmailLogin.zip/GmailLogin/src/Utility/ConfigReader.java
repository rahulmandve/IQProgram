package Utility;

import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {
	Properties pro;
	public ConfigReader() {
		try {
			FileInputStream fis=new FileInputStream("./Config/config.property");
			pro=new Properties();
			pro.load(fis);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public String getChromePath()
	{
		return pro.getProperty("ChromePath");
	}
	public String getWebSiteUrl()
	{
		return pro.getProperty("websiteurl");
	}
	public String getClickOnSign()
	{
		return pro.getProperty("ClickOnSignin");
	}
	public String getUnameId()
	{
		return pro.getProperty("UnameId");
	}

	public String getClickOnNext()
	{
		return pro.getProperty("ClickOnNext");
	}
	public String getPassXpath()
	{
		return pro.getProperty("PassXpath");
	}

	public String getClickOnNextid()
	{
		return pro.getProperty("ClickOnNextid");
	}
	public String getComposeXpath()
	{
		return pro.getProperty("ComposeXpath");
	}
	public String getToxpath()
	{
		return pro.getProperty("Toxpath");
	}
	public String getSubjectXpath()
	{
		return pro.getProperty("SubjectXpath");
	}
	public String getsendButtonCss()
	{
		return pro.getProperty("sendButtonCss");
	}

}