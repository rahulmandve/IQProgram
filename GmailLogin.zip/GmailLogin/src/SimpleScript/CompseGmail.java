package SimpleScript;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;



public class CompseGmail {
	
	WebDriver d;
	@BeforeMethod
	public void openBrowser()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Desktop\\chromedriver_win32\\chromedriver.exe");
		d=new ChromeDriver();
		d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		d.manage().window().maximize();
		
		d.get("https://www.google.com/gmail/about/");
		
	}
	@Test
	public void commail() throws Exception
	{
		d.findElement(By.partialLinkText("SIGN")).click();
	
		d.findElement(By.id("identifierId")).sendKeys("rahul.mandwe259@gmail.com");
		
		d.findElement(By.id("identifierNext")).click();
		
		d.findElement(By.xpath("//*[@id='password']/div[1]/div/div[1]/input")).sendKeys("rahul@123");
		
		d.findElement(By.id("passwordNext")).click();
		
		Thread.sleep(3000);
		d.findElement(By.xpath("//*[contains(@class, 'nH') and contains(@class, 'oy8Mbf') and contains(@class,'nn')]/div[1]/div[2]/div/div/div/div[1]/div/div")).click();
		Thread.sleep(2000);
		
		//d.findElement(By.xpath("//*[@id=':pm']/div")).click();
		
		d.findElement(By.xpath("//textarea[@rows='1'  and @name='to']")).sendKeys("rahul.mandve@yahoo.com");
		
		d.findElement(By.xpath("//input[@name='subjectbox' and @placeholder='Subject']")).sendKeys("selenium Mail Testing");
		//attach xpath //div[@class='a1 aaA aMZ' and @id=':pq']
			
		d.findElement(By.cssSelector(".aDh>Table>:nth-child(2)>tr>:nth-child(1)>div>:nth-child(2)")).click();
		
	}
	
	/*@AfterMethod
	public void closeBrowser()
	{
		d.quit();
	}
*/
}
