package ExcelSheetReader;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReader {
	XSSFWorkbook book;
	XSSFSheet sheet;
	public ExcelReader(String path) {
		// TODO Auto-generated constructor stub
		
		try {
			File src=new File(path);
			FileInputStream fis=new FileInputStream(src);
			book=new XSSFWorkbook(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public int getRowcount(String sheetIndex)
	{
		int row=book.getSheet("GmailLogin").getLastRowNum()+1;
				return row;
	}

	
	public String getdata(int sheetnumber,int row,int col)
	{
		sheet=book.getSheetAt(sheetnumber);
		String data=sheet.getRow(row).getCell(col).getStringCellValue();
		return data;
	}
	
}
