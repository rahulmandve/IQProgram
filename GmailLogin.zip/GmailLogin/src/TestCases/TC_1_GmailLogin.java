package TestCases;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import ChromeDriver.LaunchBrowser;
import ExcelSheetReader.ExcelReader;
import Utility.ConfigReader;

public class TC_1_GmailLogin extends LaunchBrowser
{
	
	ConfigReader conf=new ConfigReader();
	
	@Test(dataProvider="data")
	public void login(String un,String ps,String to,String sub) throws Exception
	{
		d.findElement(By.partialLinkText(conf.getClickOnSign())).click();
		d.findElement(By.id(conf.getUnameId())).sendKeys(un);
		d.findElement(By.id(conf.getClickOnNext())).click();
		d.findElement(By.xpath(conf.getPassXpath())).sendKeys(ps);
		d.findElement(By.id(conf.getClickOnNextid())).click();
	
		d.findElement(By.xpath(conf.getComposeXpath())).click();
		d.findElement(By.xpath(conf.getToxpath())).sendKeys(to);
		d.findElement(By.xpath(conf.getSubjectXpath())).sendKeys(sub);
		
		//Assert.assertEquals(d.getCurrentUrl(),"https://mail.google.com/mail/u/0/#inbox");
	
		d.findElement(By.xpath("//*[contains(@class,'a1 aaA aMZ')]")).click();
		
		Robot r=new Robot();
		StringSelection s=new StringSelection("C:\\Users\\hp\\Desktop\\TestData.xlsx");
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);
		Thread.sleep(3000);
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_V);
		Thread.sleep(3000);
		r.keyPress(KeyEvent.VK_ENTER);
		d.findElement(By.cssSelector(conf.getsendButtonCss())).click();
	}

	@DataProvider(name="data")
	public Object[][] testdata() throws Exception
	{

		ExcelReader er=new ExcelReader("C:\\Users\\hp\\Desktop\\TestData.xlsx");
		int rows=er.getRowcount("GmailLogin");
		Object [][]data=new Object[rows][4];
		
		for(int i=0;i<rows;i++)
		{
			data[i][0]=er.getdata(1, i, 0);
			data[i][1]=er.getdata(1, i, 1);
			data[i][2]=er.getdata(1, i, 2);
			data[i][3]=er.getdata(1, i, 3);
			
		}
		
		
		return data;
	}
	
	
	
}
