import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class HandlingWebTable 
{
	public static void main(String[] args) throws InterruptedException
	{
		
		WebDriver d=new FirefoxDriver();
		d.manage().window().maximize();
		
	}
}
