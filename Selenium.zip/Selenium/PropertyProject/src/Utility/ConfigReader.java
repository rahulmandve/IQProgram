package Utility;


import java.io.FileInputStream;
import java.util.Properties;

public class ConfigReader {
	
	Properties pro;
	
	public ConfigReader() {
	
		try{
		
		FileInputStream fis=new FileInputStream("./configration/config.property");
		pro=new Properties();
		pro.load(fis);
		}catch(Exception e)
		{
			System.out.println("Exception"+e.getMessage());
		}
	}
public String getChromePath()
{
	return pro.getProperty("ChromeDriver");
}
public String getUrl() {
	return pro.getProperty("URL");
}
public String getUnameId()
{
	return pro.getProperty("UnameId");	
}
public String getPassId()
{
	return pro.getProperty("PassId");
}
public String getButton()
{
	return pro.getProperty("Button");
}
}
