package ConfigrutionDemo;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import Utility.ConfigReader;

public class TestSeleniumChrome {
	
	ConfigReader confi;
	@BeforeTest
	public void setUP()
	{
		confi=new ConfigReader();
		System.setProperty("webdriver.chrome.driver",confi.getChromePath());
		System.out.println("=====Setup is ready======");
	}
	@Test
	public void testChrom() throws Exception
	{	

		System.out.println("=====test Started=======");
		WebDriver d=new ChromeDriver();
		
		d.get(confi.getUrl());
		d.findElement(By.id("email")).sendKeys(confi.getUnameId());
		d.findElement(By.id("pass")).sendKeys(confi.getPassId());
		d.findElement(By.id("loginbutton")).click();
		System.out.println("=====Test ended======");
		
	}

}
