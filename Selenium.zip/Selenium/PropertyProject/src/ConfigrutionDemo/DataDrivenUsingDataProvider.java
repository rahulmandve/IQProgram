package ConfigrutionDemo;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Utility.ConfigReader;

public class DataDrivenUsingDataProvider 
{
	ConfigReader conf;
	@BeforeTest	
	public void SetUp()
	{
		conf=new ConfigReader();
		System.setProperty("webdriver.chrome.driver",conf.getChromePath());
		System.out.println("====SetUp ready===");
	}
	@Test(dataProvider="fbdata")
	public void FBLogin(String uname,String pass)
	{
		System.out.println("===Script started===");
		WebDriver d=new ChromeDriver();
		d.get(conf.getUrl());
		d.findElement(By.id("email")).sendKeys(uname);
		d.findElement(By.id("pass")).sendKeys(pass);
		d.findElement(By.id("loginbutton")).click();
		
		Assert.assertFalse(d.getTitle().contains("Facebook"));
		System.out.println("=====Script ended======");
	}
	@DataProvider (name="fbdata")
	public Object[][] testData()
	{
		Object[][] data=new Object[2][2];
		
		data[0][0]="95618776666";
		data[1][0]="fgtgvkk";
		
		data[1][0]="9561877666";
		data[1][1]="ram@123";
	
		return data;
	}

}
