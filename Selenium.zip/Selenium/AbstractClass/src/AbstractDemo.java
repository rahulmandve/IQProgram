
abstract class A
{
	A()
	{
		System.out.println("abstract Class Const");
	}
	abstract protected void m1();
	void m2()
	{
		System.out.println("imple m2 of A");
	}
}
public class AbstractDemo extends A {
	public AbstractDemo() {
		super();
	System.out.println("abstractdemo const");
	}
	public void m1()
	{
		System.out.println("m1");
	}
	void m2()
	{
		System.out.println("abstr class M2");
	}
public static void main(String[] args) {
	
	A a=new AbstractDemo();
	a.m1();
	a.m2();
}
}
