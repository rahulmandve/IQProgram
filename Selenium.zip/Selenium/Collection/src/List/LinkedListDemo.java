package List;

import java.util.LinkedList;

public class LinkedListDemo {
public static void main(String[] args) {
	LinkedList l=new LinkedList();
	l.add("rahul");
	l.add(111);
	l.add(null);
	l.add(null);
	l.add('R');
	l.add("rahul");
	System.out.println(l);
	
	l.removeFirst();
	System.out.println(l);
	
	l.addLast("mandve");
	System.out.println(l);
	
	System.out.println(l.getLast());
	
	System.out.println(l.indexOf('R'));
	
	
	
}
}
