package List;

import java.util.Vector;

public class VectorDemo {
public static void main(String[] args) {
	Vector v=new Vector();
	System.out.println(v.capacity());
	/*v.addElement("rahul");
	v.addElement(111);
	v.addElement(null);
	v.addElement("rahul");
	v.addElement('R');
	System.out.println(v);
	
	System.out.println(v.remove(2));
	
	System.out.println(v.capacity()); */
	for(int i=1; i<=10; i++)
	{
		v.addElement(i);
	}
	System.out.println(v);
	
	v.add(100);
	
	System.out.println(v.capacity());
	for(int i=1;i<=10;i++)
	{
		v.addElement(i);
	}
	System.out.println(v.capacity());
	
	
	
}
}
