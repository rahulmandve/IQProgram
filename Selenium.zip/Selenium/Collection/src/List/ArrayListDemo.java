package List;

import java.util.ArrayList;

public class ArrayListDemo {
public static void main(String[] args) {

	ArrayList al=new ArrayList();
	al.add("rahul");
	al.add(111);
	al.add(null);
	al.add(null);
	al.add('A');
	System.out.println(al);
	System.out.println(al.size());
	
	al.remove(1);
	System.out.println(al);
	
	System.out.println(al.clone());
	
	System.out.println(al.isEmpty());
	//al.clear();
	//System.out.println(al.isEmpty());
	
	System.out.println(al.hashCode());
}
}
