package Cursors;

import java.util.Enumeration;
import java.util.Vector;

public class EnumerationDemo {
public static void main(String[] args) {
	Vector c=new Vector();
	for(int i=1;i<=10;i++)
	{
		c.addElement(i);
	}
	System.out.println(c);
	
	Enumeration e=c.elements();
	while(e.hasMoreElements())
	{
		Integer i=(Integer)e.nextElement();
		if(i%2==0)
		{
			System.out.println(i);
		}
			
	}
}
}
