package Cursors;

import java.util.LinkedList;
import java.util.ListIterator;

public class ListIteratorDemo {
public static void main(String[] args) {
	LinkedList l=new LinkedList();
	l.add("A");
	l.add("B");
	l.add("C");
	l.add("D");
	System.out.println(l);
	ListIterator li=l.listIterator();
	
	while(li.hasNext())
	{
		String s=(String)li.next();
				if(s.equals("B"))
				{
					li.set("Rahul");
				}
				else if(s.equals("D"))
				{
					li.add("Mandve");
				}
	}
	System.out.println(l);
}
	
}
