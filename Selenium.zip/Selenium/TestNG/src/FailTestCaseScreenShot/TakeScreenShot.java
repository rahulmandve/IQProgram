package FailTestCaseScreenShot;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.Test;

public class TakeScreenShot extends TestMain
{	
	public static String screenshot(String s) throws Exception
	{
			TakesScreenshot t=(TakesScreenshot)d;
			File src=t.getScreenshotAs(OutputType.FILE);
			String path=System.getProperty("user.dir")+"/ScreenShot/"+s+".png";
			//String path=System.getProperty("C:\\Users\\hp\\Desktop\\VideoRec"+s+".png");
			File desti=new File(path);
			FileUtils.copyFile(src,desti);
			System.out.println("screenshot taken");
			
			return path;
	
	}
}
