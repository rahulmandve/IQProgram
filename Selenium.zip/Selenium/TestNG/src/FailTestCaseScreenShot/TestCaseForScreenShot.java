package FailTestCaseScreenShot;


import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TestCaseForScreenShot extends TestMain{
@Test
public void BrowserLounch()
{
	d=new FirefoxDriver();
	d.manage().window().maximize();
	d.get("http://www.facebook.com");
	String s=d.getTitle();
	System.out.println(s);
	
	Assert.assertEquals("Facebook",s);

	
}
@Test
public void login()
{
	d.findElement(By.xpath(".//*[@id='email']")).sendKeys("9561877666");
	d.findElement(By.xpath(".//*[@id='pass']")).sendKeys("ram@123");
	d.findElement(By.xpath(".//*[@id='loginbutton']")).click();
}


}
