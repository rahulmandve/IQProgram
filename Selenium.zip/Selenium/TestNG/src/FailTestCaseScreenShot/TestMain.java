package FailTestCaseScreenShot;

import org.openqa.selenium.WebDriver;

public class TestMain {
public static WebDriver d;
}
