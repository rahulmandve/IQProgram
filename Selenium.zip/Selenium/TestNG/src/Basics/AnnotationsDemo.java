package Basics;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AnnotationsDemo {
//Test case 1
	@Test
	public void testCase1(){
		System.out.println("in test case 1");
	}
	//test case 2
	@Test
	public void testCase2()
	{
		System.out.println("in test case 2");
	}
	@BeforeMethod
	public void beforeMethod()
	{
		System.out.println("in befor method");
	}
	@AfterMethod
	public void afterMethod()
	{
		System.out.println("in after method");
	}
	@BeforeClass
	 public void beforClass()
	 {
		System.out.println("in befor class");
	 }
	@AfterClass
	public void afterClass()
	{
		System.out.println("in after class");
	}
	@BeforeTest
	public void beforTest()
	{
		System.out.println("in befor test");
	}
	@AfterTest
	public void afterTest()
	{
		System.out.println("in after Test");
	}
	@BeforeSuite
	public void beforSuite()
	{
		System.out.println("in beforSuite");
	}
	@AfterSuite
	public void afterSuite()
	{
		System.out.println("in after suite");
	}
	
	
}
