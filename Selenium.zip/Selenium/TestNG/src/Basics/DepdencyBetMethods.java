package Basics;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DepdencyBetMethods {
	
	@Test(priority=1)
	public void StarApp()
	{
		
		System.out.println("starting application");
	}
	@Test(priority=2)
	public void LoginApp()
	{
		System.out.println("Login application");
		Assert.assertEquals(12, 13);
	}
	@Test(dependsOnMethods="LoginApp")
	public void LogoutApp()
	{
		System.out.println("logout application");
	}
}
