package Basics;

import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginApplication {

	@Test(priority=3,description="first test case login ")
	public void firstest()
	{
		System.out.println("first testcase");
		Assert.assertEquals(12, 13);
	}
	@Test(priority=2,description="this is second test case")
	public void secondtest()
	{
		System.out.println("Second testcase");
	}
	@Test(priority=1,description="this is third case of exection")
	public void thirdtest()
	{
		System.out.println("third test case");
	}
}
