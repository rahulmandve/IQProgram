package Basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParaUsingXML {
	WebDriver d;
	@Test
	@Parameters("browser")
	public void paraTest(String browser) throws InterruptedException
	{
		if(browser.equals("firefox"))
		{
			d=new FirefoxDriver();
			d.get("http://www.facebook.com");
			d.manage().window().maximize();
			System.out.println("Open FireFox Browser");
		}
		else if(browser.equals("Chrome"))
		{
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\hp\\Desktop\\chromedriver_win32\\chromedriver.exe");
			d.get("http://www.google.com");
			Thread.sleep(3000);
			d.manage().window().maximize();
			System.out.println("Open Chorme Browser");
		}
	}
}
