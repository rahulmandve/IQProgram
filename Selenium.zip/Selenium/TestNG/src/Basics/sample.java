package Basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class sample {
	@Test
	public void verifyTitle()
	{
		WebDriver d=new FirefoxDriver();
		d.get("http://www.gmail.com");
		String a=d.getTitle();
		Assert.assertEquals(a, "Gmail");
	}
}
