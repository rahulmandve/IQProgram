package Basics;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TestAnnotation {
	@Test
	public void test()
	{
		System.out.println("in test");
	}
	@Test
	public void Test1()
	{
		System.out.println(" test1");
	}
	@Test
	public void Test2()
	{
		System.out.println("test2");
	}

}
