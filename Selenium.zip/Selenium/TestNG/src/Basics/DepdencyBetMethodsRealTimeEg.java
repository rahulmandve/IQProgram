package Basics;

import java.util.concurrent.TimeUnit;

import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class DepdencyBetMethodsRealTimeEg {
	
	WebDriver d;
	@org.testng.annotations.BeforeClass	
	public void Start()
	{
		//System.setProperty("webdriver.chrome.driver","C:\\Users\\hp\\Desktop\\chromedriver_win32\\chromedriver.exe");
		d=new FirefoxDriver();
		System.out.println("=====Browser Loaded====");
	}
	@Test
	public void StarApp()
	{
		
		d.manage().window().maximize();
		d.get("https://www.facebook.com/");
		d.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		String url=d.getCurrentUrl();
		//Assert.assertTrue(url.contains(".facebook.com"));
		System.out.println("Application Open");
	}
	@Test(dependsOnMethods="StarApp")
	public void LoginApp()
	{
		d.findElement(By.xpath(".//*[@id='email']")).sendKeys("9561877666");
		d.findElement(By.xpath(".//*[@id='pass']")).sendKeys("ram@123");
		d.findElement(By.xpath(".//*[@id='u_0_2']")).click();
		
		//boolean status=d.findElement(By.xpath(".//*[@id='u_0_c']/a")).isDisplayed();
		//Assert.assertTrue(status);
		System.out.println("Login Successful");
	}
	@Test(dependsOnMethods="LoginApp")
	public void LogoutApp() throws InterruptedException
	{
		d.findElement(By.xpath(".//*[@id='userNavigationLabel']")).click();
		Thread.sleep(2000);
		d.findElement(By.partialLinkText("Log")).click();
		Assert.assertTrue(d.findElement(By.xpath(".//*[@id='email']")).isDisplayed());
		System.out.println("Logout successful");
	}
	@AfterClass
	public void end()
	{
		d.quit();
		System.out.println("====Close Browser===");
	}
}
