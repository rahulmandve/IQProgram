package Basics;

import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class parameter {
	@Test
	@Parameters("testpara")
	public void sampleTest(String sample)
	{
		System.out.println("value para"+sample);
	}
}
