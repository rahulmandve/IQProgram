package Basics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

public class ErrorHandling {
	WebDriver d;
	@Test(priority=1)
	public void VerifyErrorMessage()
	{
		d=new FirefoxDriver();
		d.manage().window().maximize();
		d.get("https://accounts.google.com/signin/v2/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&service=mail&sacu=1&rip=1&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
		
		
	}
	/*@Test(priority=2)
	public void FindElement()
	{
		d.findElement(By.xpath("html/body/nav/div/a[2]")).click();
				
	}*/
	@Test(priority=2)
	public void showmsg()
	{
		d.findElement(By.xpath(".//*[@id='identifierNext']/content/span")).click();
		String s =d.findElement(By.xpath(".//*[@id='view_container']/div/div[2]/div/form/div[1]/div/div[2]/div[2]")).getText();
		System.out.println(s);
		Assert.assertTrue(d.findElement(By.xpath(".//*[@id='identifierId']")).isDisplayed());
		System.out.println("Display Error Message");

	}
	@AfterClass
	public void CloseWindow()
	{
		d.quit();
	}

}
