package Basics;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class VerifyTitle {
	
	@Test
	public void VerifyApplicationTitle()
	{
		WebDriver d=new FirefoxDriver();
		d.manage().window().maximize();
		d.get("http://www.facebook.com");
	String s="facebook";
	Assert.assertEquals("Facebook � log in or sign up", d.getTitle());
	
		
		
	}
	

}
