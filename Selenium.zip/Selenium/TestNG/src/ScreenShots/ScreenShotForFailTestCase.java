package ScreenShots;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

public class ScreenShotForFailTestCase {
	WebDriver d;
	@Test	
	public void capturescreen() throws Exception {
	d=new FirefoxDriver();
		d.get("http://www.facebook.com");
		d.manage().window().maximize();
		
		d.findElement(By.xpath(".//*[@id='email']")).sendKeys("rahul");
	
		
	}
	@AfterMethod
	public void terDown(ITestResult is) throws Exception{
		if(is.FAILURE==is.getStatus())
		{
			utility.screenshot(d, is.getName());
		}
		d.quit();
	}
}
