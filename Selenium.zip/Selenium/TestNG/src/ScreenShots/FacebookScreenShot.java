package ScreenShots;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import com.sun.jna.platform.FileUtils;

public class FacebookScreenShot {
@Test	
public void capturescreen() throws Exception {
	WebDriver d=new FirefoxDriver();
	d.get("http://www.facebook.com");
	d.manage().window().maximize();
	utility.screenshot(d,"mainpage");
	d.findElement(By.xpath(".//*[@id='email']")).sendKeys("rahul");
	
	utility.screenshot(d,"facebook");
	d.quit();
}
}
