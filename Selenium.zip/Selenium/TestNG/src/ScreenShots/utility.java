package ScreenShots;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

public class utility {
public static void screenshot(WebDriver d,String s) throws Exception
{
	try {
		TakesScreenshot t=(TakesScreenshot)d;
		File f=t.getScreenshotAs(OutputType.FILE);
		org.apache.commons.io.FileUtils.copyFile(f,new File("C:\\Users\\hp\\Desktop\\VideoRec"+s+".png"));
		System.out.println("screenshot taken");
	} catch (Exception e) {
		System.out.println(e);
	} 	
}
}
