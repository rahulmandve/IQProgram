package ListenersDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners(ListenersDemo.TestNGListener.class)
public class MyFirstTestCase {
	
	@Test
	public void googletitle()
	{
	WebDriver d=new FirefoxDriver();
	d.get("http://google.com");
	d.manage().window().maximize();
	System.out.println(d.getTitle());

}
	@Test
	public void titlematch()
	{
	System.out.println("test 2 dummy");
	Assert.assertTrue(false);
	
}
}
