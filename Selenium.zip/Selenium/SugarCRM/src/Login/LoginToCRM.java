package Login;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class LoginToCRM 
{
	
	public static void main(String []args) 
	{
		//System.setProperty("webdriver.chorme.driver","C:\\Users\\hp\\Desktop\\chromedriver_win32\\chromedriver.exe");
		
		WebDriver d=new FirefoxDriver();
		d.get("http://sugar.cyberdroid.biz");
		d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		d.manage().window().maximize();
		d.findElement(By.xpath("//input[@name='user_name']")).sendKeys("mrahul11");
		d.findElement(By.xpath("//input[@name='user_password']")).sendKeys("rahul@123");
		d.findElement(By.xpath("//input[@id='login_button']")).click();
		/*//Using JavaScriptExcutor
		JavascriptExecutor js=(JavascriptExecutor)d;
		js.executeScript("document.getElementByXpath('//input[@name='user_name']').value='mrahul';");*/
		
			
	}

}
