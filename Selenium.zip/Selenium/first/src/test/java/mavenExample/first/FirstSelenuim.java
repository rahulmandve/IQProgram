package mavenExample.first;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

public class FirstSelenuim {
	public static WebDriver d;
	@Test
	public void OpenBrowser()
	{
		System.setProperty("webdriver.chrome.driver","F:\\Win10 Setups\\ChromeSetup.exe");
		d=new ChromeDriver();
		d.manage().window().maximize();
		d.get("http://www.facebook.com");
	}
	@Test
	public void FindElement()
	{
		d.findElement(By.name("email"));
		d.findElement(By.name("pass"));
		d.findElement(By.id("loginbutton")).click();
	}
	
}
