package ProductFind;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Men {
	public static void main(String[] args) {
		WebDriver d=new FirefoxDriver();
	d.manage().window().maximize();
	d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	d.get("https://www.flipkart.com/mens-clothing/tshirts/pr?sid=2oq%2Cs9b%2Cj9y&otracker=nmenu_sub_Men_0_T-Shirts&page=4");
	WebElement e=d.findElement(By.xpath("//div[@class='_3Ed3Ub' ]/ul/li[3]"));
	Actions a=new Actions(d);
	a.moveToElement(e).build().perform();
	d.findElement(By.partialLinkText("Boots")).click();
	
	}

}
