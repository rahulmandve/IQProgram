
public class datatype {
	public void m()
	{
		int s=1;
		System.out.println(s);
	}
	
	public static void main(String[] args) {
		datatype d=new datatype();
		d.m();
	
	}
}
