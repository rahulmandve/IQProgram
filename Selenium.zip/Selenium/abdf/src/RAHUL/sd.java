package RAHUL;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class sd {

	public static void main(String[] args) {
	WebDriver d=new FirefoxDriver();

	}

}
