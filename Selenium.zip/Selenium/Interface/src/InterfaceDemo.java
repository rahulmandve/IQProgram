
interface A 
{

	int i=10;
	void m1();
	void m2();
	static void m3()
	{
		System.out.println("interface method");
	}
}
public class InterfaceDemo  implements A{
	public InterfaceDemo() {
	super();
	System.out.println("interfaceDemo const");
	}
public void m1()
	{
		System.out.println("m1");
	}
public void m2()
{
	System.out.println("m2");
}
 static final synchronized strictfp public void main(String[] rahul) {
	InterfaceDemo d=new InterfaceDemo();
	d.m1();
	d.m2();
	A.m3();
	System.out.println(A.i);
	System.out.println(d.toString());
	//return 0; //change return type of method to int or void can not return a value
}
}
