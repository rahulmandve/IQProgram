package tiksha;

public class launchedbrows {
	public static void main(string[] args){
		WebDriver d= new FirefoxDriver();
		d.get("http://www.Google.co.in");
		d.manage().windows().maximize();
		Thread.sleep(2000);
	}

}
