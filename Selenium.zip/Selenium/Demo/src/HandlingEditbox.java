import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

public class HandlingEditbox {

	public static void main(String[] args) throws InterruptedException {
		WebDriver d = new FirefoxDriver();
		d.manage().window().maximize();
		d.get("https://www.google.co.in/?gfe_rd=cr&dcr=0&ei=6xO6WpsjjoWHA7LtqLgO");
		Thread.sleep(2000);
		WebElement e = d.findElement(By.id("lst-ib"));
		e.sendKeys("Prasad Rajput");
		WebElement e1 = d.findElement(By.xpath(".//*[@id='tsf']/div[2]/div[3]/center/input[1]"));
		e1.click();
		
		

	}

	

}
