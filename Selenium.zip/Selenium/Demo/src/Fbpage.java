import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class Fbpage {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver d = new FirefoxDriver();
		d.mange();
		d.manage().window().maximize();
		d.get("https://www.facebook.com/");
		Thread.sleep(2000);

	
		d.findElement(By.xpath(".//*[@id='u_0_m']")).sendKeys("Prasad");
		
		d.findElement(By.xpath(".//*[@id='u_0_o']")).sendKeys("Chavan");
		
		d.findElement(By.xpath(".//*[@id='u_0_r']")).sendKeys("123654");
		
		d.findElement(By.xpath(".//*[@id='u_0_y']")).sendKeys("java123");
		
		WebElement e=d.findElement(By.xpath(".//*[@id='day']"));
		
		Select s= new Select(e);
		s.selectByIndex(10);
		WebElement f=d.findElement(By.xpath(".//*[@id='month']/option[6]"));
		Select i= new Select(f);
		i.selectByValue("5");
		WebElement g=d.findElement(By.xpath(".//*[@id='year']/option[28]"));
		Select p= new Select(g);
		p.selectByValue("1992");
		
		
		
	
		
		
	}
	

}
