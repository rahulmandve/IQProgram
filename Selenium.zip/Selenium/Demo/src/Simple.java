import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Simple {

	public static void main(String[] args) throws InterruptedException 
	{
	WebDriver d = new FirefoxDriver();
	d.manage().window().maximize();
	d.get("https://www.google.co.in/?gfe_rd=cr&dcr=0&ei=6xO6WpsjjoWHA7LtqLgO");
	Thread.sleep(200);
	String s=d.getTitle();
	System.out.println(s);
	String r=d.getCurrentUrl();
	System.out.println(r);
	d.navigate().to("http://www.Facebook.com");
	String s1=d.getTitle();
	System.out.println(s1);



	}

}
