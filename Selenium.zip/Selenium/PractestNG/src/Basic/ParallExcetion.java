package Basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

public class ParallExcetion {
/*@Test
public void login()
{
	System.out.println("login");
}
@Test 
public void search()
{
	System.out.println("search");
	//Assert.assertEquals(12, 13);
}
@Test
public void addsearch()
{
System.out.println("addsearch");	
}
@Test
public void logout()
{
System.out.println("logout")	
}*/
	@Test
	public void facebook()
	{
		WebDriver d=new FirefoxDriver();
		d.get("http://www.facebook.com");
		//d.manage().window().maximize();
		System.out.println("Lounching facebook with Firefox"+Thread.currentThread().getId());
		d.findElement(By.id("email")).sendKeys("9561877666");
		d.findElement(By.id("pass")).sendKeys("ram@123");
		//d.findElement(By.id("loginbutton")).click();
	}
	@Test
	public void facebook1()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\hp\\Desktop\\chromedriver_win32\\chromedriver.exe");
		WebDriver d= new ChromeDriver();
		d.get("http://www.facebook.com");
		//d.manage().window().maximize();
		System.out.println("lounching facebook with chrome"+Thread.currentThread().getId());
		d.findElement(By.id("email")).sendKeys("9561877666");
		d.findElement(By.id("pass")).sendKeys("ram@123");
		//d.findElement(By.id("loginbutton")).click();
	}
	@Test
	public void facebook2()
	{
		System.setProperty("webdriver.ie.driver","F:\\Win10 Setups\\IE 32bit\\IEDriverServer.exe");
		WebDriver d=new InternetExplorerDriver();
		d.get("http://www.facebook.com");
		System.out.println("lounching facebook with IE"+Thread.currentThread().getId());
		d.findElement(By.id("email")).sendKeys("9561877666");
		d.findElement(By.id("pass")).sendKeys("ram@123");
		//d.findElement(By.id("loginbutton")).click();
		
	}
	
}
