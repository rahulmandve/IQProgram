package Basic;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DepOnMethod {
@Test
public void login()
{
	System.out.println("login");
}
@Test (dependsOnMethods="login")
public void search()
{
	System.out.println("search");
	Assert.assertEquals(12, 13);
}
@Test(dependsOnMethods="search")
public void addsearch()
{
System.out.println("addsearch");	
}
@Test(dependsOnMethods="addsearch")
public void logout()
{
System.out.println("logout");	
}
}
