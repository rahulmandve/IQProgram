package Basic;

import org.junit.runners.Parameterized.Parameters;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;



public class SkipTestCase {
	@Test
	public void login()
	{
		System.out.println("login");
	}
	@Test 
	public void search() 
	{
		System.out.println("search");
		
		//Assert.assertEquals(12, 13);
	}
	@Test 
	public void addsearch()
	{
		String s="test skip";
		if(s.equalsIgnoreCase("test skip"))
		{
			throw new SkipException("Skipping:this test case is skipped");
		}else{
		System.out.println("I am in else statment");
		}
		System.out.println("i am out of else statment");
	}
	@Test
	public void logout()
	{
		System.out.println("logout");	
	}
}
