package Basic;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
public class DataProvider {
	
	@Test(dataProvider="getdata")
	public void FBLogine(String uname,String pwd)
	{System.setProperty("webdriver.chrome.driver","C:\\Users\\hp\\Desktop\\chromedriver_win32\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		d.get("http://www.facebook.com");
		d.manage().window().maximize();
		d.findElement(By.id("email")).sendKeys(uname);
		d.findElement(By.id("pass")).sendKeys(pwd);
		//d.findElement(By.id("loginbutton")).click();
	
		
	}
	
	@org.testng.annotations.DataProvider(name="getdata")
	public Object[][] getdata()
	{
		Object [][] data=new Object[2][2];
	
		data[0][0]="9561877666";
		data[0][1]="ram@123";
		
		data[1][0]="rahul mandve";
		data[1][1]="ram@123";
				
		return data;
	}

}
