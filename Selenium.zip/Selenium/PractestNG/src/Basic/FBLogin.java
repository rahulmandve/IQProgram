package Basic;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

public class FBLogin {
	ReadProperty pro=new ReadProperty();
	WebDriver d;
	@BeforeMethod
	public void BOpen()
	{
		//System.setProperty("webdriver.chorme.driver","C:\\Users\\hp\\Desktop\\chromedriver_win32\\chromedriver.exe");
		d=new FirefoxDriver();
		d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		d.get("http://www.facebook.com");
		
	}
	@Test
	public void Login()
	{
		d.findElement(By.id("email")).sendKeys(pro.getUsername());
		d.findElement(By.id("pass")).sendKeys(pro.getPassword());
		d.findElement(By.id("loginbutton")).click();
	}
	/*@AfterMethod
	public void close()
	{
		d.quit();
	}*/

}
