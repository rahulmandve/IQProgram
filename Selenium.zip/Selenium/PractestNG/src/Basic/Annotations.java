package Basic;

import org.junit.AfterClass;
import org.testng.annotations.AfterGroups;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeGroups;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Annotations {
	@BeforeTest
	public void m1()
	{
		System.out.println("Before test ");
	}
	@AfterTest
	public void A2()
	{
		System.out.println("After Test ");
	}
	@Test
	public void m3()
	{
		System.out.println("Test 1");
	}
	@BeforeMethod
	public void M4()
	{
		System.out.println("Befor method");
	}
	@Test
	public void M5()
	{
		System.out.println("test 2 ");
	}
	
	@AfterMethod
	public void M6()
	{
		System.out.println("after method ");
	}
	@BeforeClass
	public void M7()
	{
		System.out.println("befor class ");
	}
	@AfterClass
	public void M8()
	{
		System.out.println("after class ");
	}
	@BeforeSuite
	public void M9()
	{
		System.out.println("befor suite ");
	}
	@AfterSuite
	public void M10()
	{
		System.out.println("after suite ");
	}
	

}
