package Basic;

import org.testng.annotations.Test;

public class DepOnGroups 
{
@Test (groups="sanity")
public void login()
{
	System.out.println("login");
}
@Test (groups="sanity")
public void search()
{
	System.out.println("search");
	//Assert.assertEquals(12, 13);
}
@Test(groups="regression")
public void addsearch()
{
System.out.println("addsearch");	
}
@Test(groups="retest")
public void logout()
{
System.out.println("logout");	
}
}
