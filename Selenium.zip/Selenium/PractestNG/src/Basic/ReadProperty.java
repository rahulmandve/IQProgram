package Basic;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class ReadProperty {
	Properties pro;
	
	public ReadProperty()
	{
		FileInputStream f;
		try {
			f = new FileInputStream("./Confi/FBlogin.property");
			pro=new Properties();
			pro.load(f);
			}
		 catch (Exception e) {
			// TODO Auto-generated catch block
		System.out.println(e.getMessage());
		}
	}
	public String getUsername()
	{
		return pro.getProperty("username");
	}
	public String getPassword()
	{
		return pro.getProperty("password");
	}

}
